<!DOCTYPE html>
<html>
<head>
    <title>Upload CSV File</title>
</head>
<body>
    <h2>Upload CSV File</h2>
    <form action="{{ route('upload.csv') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <input type="file" name="csv_files" required>
        <button type="submit">Upload</button>
    </form>
</body>
</html>
