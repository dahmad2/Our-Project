<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Asset;
use Illuminate\Support\Facades\Storage;

class CSVImportController extends Controller
{
    /**
     * Show the CSV upload form
     */
    public function showUploadForm()
    {
        return view('upload_csv'); // Ensure 'upload_csv.blade.php' exists in resources/views
    }

    /**
     * Handle CSV file upload and import data
     */
    public function uploadCSV(Request $request)
    {
        // Validate the file upload
        $request->validate([
            'csv_file' => 'required|mimes:csv,txt|max:2048'
        ]);

        // Check if a file is uploaded
        if (!$request->hasFile('csv_file')) {
            return back()->with('error', 'No file uploaded.');
        }

        // Store the uploaded file in 'storage/app/csv_files'
        $filePath = $request->file('csv_file')->store('csv_files');
        $fileFullPath = storage_path('app/' . $filePath);

        // Check if the file exists after upload
        if (!file_exists($fileFullPath)) {
            return back()->with('error', 'File not found after upload: ' . $fileFullPath);
        }

        // Open the CSV file for reading
        $file = fopen($fileFullPath, 'r');
        $firstRow = fgetcsv($file); // Read the first row (column headers)

        // Check if the file has content
        if (!$firstRow) {
            return back()->with('error', 'The uploaded file is empty.');
        }

        // Debug: Show the first row (column headers)
        fclose($file);
        return back()->with('success', 'File uploaded successfully! First row: ' . implode(', ', $firstRow));
    }
}
