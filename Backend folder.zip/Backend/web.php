<?php

use Illuminate\Support\Facades\DB;

Route::get('/test-data', function () {
    $data = DB::table('bradfordpostcodes')->get();
    return response()->json($data);
});
